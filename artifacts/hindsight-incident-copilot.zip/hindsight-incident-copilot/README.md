# Hindsight Incident Copilot

AI incident response agent that remembers how your organization solved production problems before — powered by Hindsight agent memory + Microsoft Azure.

## What’s in this zip

| Folder | Contents |
|--------|----------|
| `website/` | Standalone demo site — open `index.html` in a browser |
| `app/` | Full React app (TanStack Start + Tailwind) used in the live preview |
| `data/` | Sample incidents, post-mortems, runbooks + Hindsight seed script |
| `backend-stub/` | FastAPI stub (`/incident`, `/retain`) |
| `docs/` | Architecture, demo script, pitch outline |
| `scripts/` | Start Hindsight with Docker |

## Quickest demo

Open `website/index.html` in a browser. Click a sample incident prompt in the console.

## Run the React app

```bash
cd app
npm install
npm run dev
```

## Optional: real Hindsight memory

```bash
export OPENAI_API_KEY=your-key
./scripts/start-hindsight.sh
cd data && pip install hindsight-client && python seed-hindsight.py
cd ../backend-stub && pip install -r requirements.txt && uvicorn main:app --reload --port 8000
```

## Pitch

> An AI Incident Response Agent that remembers how your organization solved problems before — and uses that knowledge to help engineers resolve today's production incidents faster.

- Hindsight: https://hindsight.vectorize.io/
- GitHub: https://github.com/vectorize-io/hindsight

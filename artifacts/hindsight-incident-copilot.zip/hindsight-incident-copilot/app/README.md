# Incident Copilot app

TanStack Start + React 19 + Tailwind. Preview binds to 0.0.0.0:8080.

```bash
npm install
npm run dev
```
